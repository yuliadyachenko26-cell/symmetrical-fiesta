import React, { useState, useEffect } from 'react';
import { Sparkles, RefreshCw, Moon, Sun, Star, Heart, Zap, Eye, Book } from 'lucide-react';

const DailyTarotApp = () => {
const [currentCard, setCurrentCard] = useState(null);
const [isRevealing, setIsRevealing] = useState(false);
const [isFlipped, setIsFlipped] = useState(false);
const [animation, setAnimation] = useState('idle');

const tarotCards = [
{ id: 0, name: "The Fool", element: "Air", color: "#74b9ff", keywords: ["New Beginnings","Adventure","Innocence","Leap of Faith"], advice: "Today is perfect for starting something new. Don’t overthink it—trust your instincts and take that leap. The universe supports bold moves made with an open heart.", meditation: "I embrace the unknown with childlike wonder and trust.", symbol: "⭐", animation: "float"},
{ id: 1, name: "The Magician", element: "Air", color: "#e74c3c", keywords: ["Manifestation","Power","Skill","Resources"], advice: "You have all the tools you need to succeed. Focus your intention and take inspired action. Your willpower is especially strong today—use it wisely.", meditation: "I am a powerful creator, manifesting my desires with focused intention.", symbol: "∞", animation: "pulse"},
{ id: 2, name: "The High Priestess", element: "Water", color: "#5c6bc0", keywords: ["Intuition","Mystery","Inner Wisdom","Secrets"], advice: "Trust your inner voice today. Pay attention to dreams, synchronicities, and gut feelings. Not everything needs to be logical—some wisdom comes from within.", meditation: "I trust my intuition and honor the mysteries within me.", symbol: "🌙", animation: "glow"},
{ id: 3, name: "The Empress", element: "Earth", color: "#66bb6a", keywords: ["Abundance","Nurturing","Creativity","Beauty"], advice: "Nurture yourself and your creations today. Connect with nature, appreciate beauty, and allow things to grow at their natural pace. Abundance flows when you care for yourself.", meditation: "I am worthy of abundance and nurture myself with love.", symbol: "♀", animation: "grow"},
{ id: 4, name: "The Emperor", element: "Fire", color: "#e53935", keywords: ["Authority","Structure","Leadership","Stability"], advice: "Take charge of your day with discipline and clear boundaries. Create structure where there’s chaos. Your leadership is needed—step into your power confidently.", meditation: "I lead with strength, wisdom, and fair authority.", symbol: "♂", animation: "strong"}
];

const drawCard = () => {
setIsRevealing(true);
setIsFlipped(false);
setAnimation('draw');
setTimeout(() => {
const randomCard = tarotCards[Math.floor(Math.random() * tarotCards.length)];
setCurrentCard(randomCard);
setAnimation(randomCard.animation);
setTimeout(() => setIsFlipped(true), 500);
setTimeout(() => setIsRevealing(false), 1000);
}, 1000);
};

useEffect(() => { drawCard(); }, []);

const getAnimationClass = () => {
switch(animation){
case 'draw': return 'animate-draw';
case 'float': return 'animate-float';
case 'pulse': return 'animate-pulse';
case 'glow': return 'animate-glow';
case 'grow': return 'animate-grow';
case 'strong': return 'animate-strong';
case 'wise': return 'animate-wise';
case 'heart': return 'animate-heart';
case 'charge': return 'animate-charge';
case 'roar': return 'animate-roar';
case 'flicker': return 'animate-flicker';
case 'spin': return 'animate-spin';
case 'balance': return 'animate-balance';
default: return '';
}
};

return (
<div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white p-4">
<h1 className="text-5xl font-bold text-center mb-8 flex items-center justify-center gap-3"><Sparkles/>Daily Tarot<Sparkles/></h1>
{currentCard && <div className="text-center mb-8">
<h2 className="text-3xl font-bold">{currentCard.name}</h2>
<p>{currentCard.advice}</p>
<button onClick={drawCard} disabled={isRevealing} className="mt-4 px-6 py-2 bg-yellow-400 text-black rounded-full flex items-center gap-2">{isRevealing ? "Drawing..." : "Draw New Card"} <RefreshCw/></button>
</div>}
</div>
);
};

export default DailyTarotApp;